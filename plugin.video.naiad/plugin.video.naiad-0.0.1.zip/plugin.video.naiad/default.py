import sys
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmcaddon
import xbmcplugin

from resources.lib.core.router import Router
from resources.lib.core.profiles import ProfileManager

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def main():
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    action = params.get("action", "home")

    profiles = ProfileManager()

    if not profiles.has_active():
        profiles.prompt_selection()
        return

    router = Router(HANDLE, BASE_URL, profiles.active())
    router.dispatch(action, params)


if __name__ == "__main__":
    main()
