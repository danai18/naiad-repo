from urllib.parse import urlencode

import xbmcgui
import xbmcplugin


class MenuBuilder:
    def __init__(self, handle, base_url, profile):
        self.handle = handle
        self.base_url = base_url
        self.profile = profile

    def _url(self, **params):
        return f"{self.base_url}?{urlencode(params)}"

    def _add_dir(self, label, action, params=None, art=None):
        extra = params or {}
        li = xbmcgui.ListItem(label)
        if art:
            li.setArt(art)
        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=self._url(action=action, **extra),
            listitem=li,
            isFolder=True,
        )

    def home(self, params):
        xbmcplugin.setPluginCategory(self.handle, f"Naiad — {self.profile.name}")
        xbmcplugin.setContent(self.handle, "videos")

        self._add_dir("▶  Continue Watching", "continue")
        self._add_dir("🎬  Movies", "browse_movies")
        self._add_dir("📺  TV Shows", "browse_shows")
        self._add_dir("🎌  Anime", "browse_anime")
        self._add_dir("🔍  Search", "search")
        self._add_dir("👤  Switch Profile", "switch_profile")

    def continue_watching(self, params):
        xbmcplugin.setPluginCategory(self.handle, "Continue Watching")
        xbmcplugin.setContent(self.handle, "videos")
        # TODO: pull from Trakt "in progress" for active profile

    def browse_movies(self, params):
        xbmcplugin.setPluginCategory(self.handle, "Movies")
        xbmcplugin.setContent(self.handle, "movies")
        # TODO: implement

    def browse_shows(self, params):
        xbmcplugin.setPluginCategory(self.handle, "TV Shows")
        xbmcplugin.setContent(self.handle, "tvshows")
        # TODO: implement

    def browse_anime(self, params):
        xbmcplugin.setPluginCategory(self.handle, "Anime")
        xbmcplugin.setContent(self.handle, "tvshows")
        # TODO: pull from MAL list for active profile

    def search(self, params):
        dialog = xbmcgui.Dialog()
        query = dialog.input("Search Naiad", type=xbmcgui.INPUT_ALPHANUM)
        if query:
            # TODO: fan out search across all sources
            pass

    def play(self, params):
        # TODO: resolver chain — Premiumize → scrapers → fallback
        pass
