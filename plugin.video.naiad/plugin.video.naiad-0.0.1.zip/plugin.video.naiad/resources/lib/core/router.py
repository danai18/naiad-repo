from urllib.parse import urlencode

import xbmcplugin

from resources.lib.ui.menus import MenuBuilder


class Router:
    def __init__(self, handle, base_url, profile):
        self.handle = handle
        self.base_url = base_url
        self.profile = profile
        self.menus = MenuBuilder(handle, base_url, profile)

    def url(self, **params):
        return f"{self.base_url}?{urlencode(params)}"

    def dispatch(self, action, params):
        routes = {
            "home":            self.menus.home,
            "continue":        self.menus.continue_watching,
            "browse_movies":   self.menus.browse_movies,
            "browse_shows":    self.menus.browse_shows,
            "browse_anime":    self.menus.browse_anime,
            "search":          self.menus.search,
            "play":            self.menus.play,
        }

        handler = routes.get(action)
        if handler:
            handler(params)
        else:
            self.menus.home(params)

        xbmcplugin.endOfDirectory(self.handle)
