import json
import os

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmc.translatePath(ADDON.getAddonInfo("profile"))
PROFILES_FILE = os.path.join(PROFILE_PATH, "profiles.json")
ACTIVE_FILE = os.path.join(PROFILE_PATH, "active_profile.json")


class Profile:
    def __init__(self, data):
        self.id = data["id"]
        self.name = data["name"]
        self.avatar = data.get("avatar", "")
        self.trakt_token = data.get("trakt_token")
        self.mal_token = data.get("mal_token")
        self.language = data.get("language", "en")
        self.prefer_dub = data.get("prefer_dub", False)
        self.kids_mode = data.get("kids_mode", False)

    def to_dict(self):
        return self.__dict__


DEFAULT_PROFILES = [
    {"id": "danielle", "name": "Danielle", "avatar": "", "language": "en", "prefer_dub": False, "kids_mode": False},
]


class ProfileManager:
    def __init__(self):
        os.makedirs(PROFILE_PATH, exist_ok=True)
        self._profiles = self._load_profiles()
        self._active = self._load_active()

    def _load_profiles(self):
        if not os.path.exists(PROFILES_FILE):
            self._save_profiles(DEFAULT_PROFILES)
            return [Profile(p) for p in DEFAULT_PROFILES]
        with open(PROFILES_FILE, "r") as f:
            return [Profile(p) for p in json.load(f)]

    def _save_profiles(self, data):
        with open(PROFILES_FILE, "w") as f:
            json.dump(data, f, indent=2)

    def _load_active(self):
        if not os.path.exists(ACTIVE_FILE):
            return None
        with open(ACTIVE_FILE, "r") as f:
            data = json.load(f)
            pid = data.get("id")
            return next((p for p in self._profiles if p.id == pid), None)

    def _save_active(self, profile):
        with open(ACTIVE_FILE, "w") as f:
            json.dump({"id": profile.id}, f)

    def has_active(self):
        return self._active is not None

    def active(self):
        return self._active

    def all_profiles(self):
        return self._profiles

    def prompt_selection(self):
        names = [p.name for p in self._profiles]
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Who's watching?", names)
        if idx >= 0:
            self._active = self._profiles[idx]
            self._save_active(self._active)

    def switch_profile(self):
        self._active = None
        if os.path.exists(ACTIVE_FILE):
            os.remove(ACTIVE_FILE)
        self.prompt_selection()

    def add_profile(self, name, **kwargs):
        pid = name.lower().replace(" ", "_")
        data = {"id": pid, "name": name, "avatar": "", "language": "en",
                "prefer_dub": False, "kids_mode": False, **kwargs}
        self._profiles.append(Profile(data))
        self._save_profiles([p.to_dict() for p in self._profiles])
